@echo off
cd /d "%~dp0"

echo Starting Backend...

start /b cmd /c uvicorn app.main:app --app-dir backend --host 127.0.0.1 --port 8000 > backend.log 2>&1

timeout /t 5 /nobreak >nul

echo Starting Frontend...

cd frontend
start /b cmd /c npm run dev > ..\frontend.log 2>&1

echo.
echo Backend : http://127.0.0.1:8000
echo Frontend: http://127.0.0.1:5173
echo.
echo Logs:
echo backend.log
echo frontend.log

pause