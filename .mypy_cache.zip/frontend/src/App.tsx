import { useState } from 'react';
import { AddTorrentModal } from './components/AddTorrentModal';
import { DetailDrawer } from './components/DetailDrawer';
import { GlobalControls } from './components/GlobalControls';
import { TaskTable } from './components/TaskTable';
import { TopBar } from './components/TopBar';
import { useTorrents } from './state/useTorrents';

export function App() {
  const torrents = useTorrents();
  const [isAddOpen, setAddOpen] = useState(false);

  return (
    <div className="app-shell">
      <TopBar
        connected={torrents.connected}
        onAdd={() => setAddOpen(true)}
        onRefresh={() => torrents.refresh().catch((err: Error) => torrents.setError(err.message))}
      />
      <main className="workspace">
        <section className="task-pane">
          <GlobalControls
            search={torrents.search}
            statusFilter={torrents.statusFilter}
            sort={torrents.sort}
            order={torrents.order}
            onSearch={torrents.setSearch}
            onStatusFilter={torrents.setStatusFilter}
            onSort={torrents.setSort}
            onOrder={torrents.setOrder}
          />
          {torrents.error && <div className="error-banner">{torrents.error}</div>}
          <TaskTable
            tasks={torrents.tasks}
            selectedId={torrents.selectedId}
            onSelect={torrents.setSelectedId}
            onAction={(id, action) =>
              torrents.runAction(id, action).catch((err: Error) => torrents.setError(err.message))
            }
          />
        </section>
        <DetailDrawer
          task={torrents.selectedTask}
          events={torrents.events}
          files={torrents.files}
          onClose={() => torrents.setSelectedId(null)}
          onAction={(id, action) =>
            torrents.runAction(id, action).catch((err: Error) => torrents.setError(err.message))
          }
          onPatch={(id, patch) =>
            torrents.patchTask(id, patch).catch((err: Error) => torrents.setError(err.message))
          }
        />
      </main>
      <AddTorrentModal
        open={isAddOpen}
        onClose={() => setAddOpen(false)}
        onAddMagnet={(payload) =>
          torrents
            .addMagnetTask(payload)
            .then(() => setAddOpen(false))
            .catch((err: Error) => torrents.setError(err.message))
        }
        onAddFile={(payload) =>
          torrents
            .addFileTask(payload)
            .then(() => setAddOpen(false))
            .catch((err: Error) => torrents.setError(err.message))
        }
      />
    </div>
  );
}
