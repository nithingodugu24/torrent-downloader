import { Pause, Play, Save, Square, X } from 'lucide-react';
import { FormEvent, useEffect, useState } from 'react';
import type { TaskEvent, TorrentFile, TorrentPatch, TorrentTask } from '../api/types';
import { formatBytes, formatPercent, formatSpeed } from '../utils/format';
import { LogPanel } from './LogPanel';

interface DetailDrawerProps {
  task: TorrentTask | null;
  events: TaskEvent[];
  files: TorrentFile[];
  onClose: () => void;
  onAction: (id: string, action: string) => void;
  onPatch: (id: string, patch: TorrentPatch) => void;
}

export function DetailDrawer({ task, events, files, onClose, onAction, onPatch }: DetailDrawerProps) {
  const [category, setCategory] = useState('');
  const [priority, setPriority] = useState(4);
  const [downloadLimit, setDownloadLimit] = useState('');
  const [uploadLimit, setUploadLimit] = useState('');
  const [maxConnections, setMaxConnections] = useState('');
  const [sequential, setSequential] = useState(false);

  useEffect(() => {
    if (!task) return;
    setCategory(task.category ?? '');
    setPriority(task.priority);
    setDownloadLimit(task.download_limit ? String(task.download_limit) : '');
    setUploadLimit(task.upload_limit ? String(task.upload_limit) : '');
    setMaxConnections(task.max_connections ? String(task.max_connections) : '');
    setSequential(task.is_sequential);
  }, [task]);

  if (!task) {
    return <aside className="detail-drawer placeholder" />;
  }

  const submit = (event: FormEvent) => {
    event.preventDefault();
    onPatch(task.id, {
      category: category || null,
      priority,
      download_limit: downloadLimit ? Number(downloadLimit) : null,
      upload_limit: uploadLimit ? Number(uploadLimit) : null,
      max_connections: maxConnections ? Number(maxConnections) : null,
      is_sequential: sequential
    });
  };

  return (
    <aside className="detail-drawer">
      <div className="detail-header">
        <div>
          <h2>{task.name || 'Metadata pending'}</h2>
          <span className={`status-chip ${task.status}`}>{task.status}</span>
        </div>
        <button className="icon-button" type="button" onClick={onClose} title="Close">
          <X size={18} aria-hidden="true" />
        </button>
      </div>
      <div className="stats-grid">
        <Metric label="Progress" value={formatPercent(task.progress)} />
        <Metric label="Downloaded" value={formatBytes(task.downloaded)} />
        <Metric label="Uploaded" value={formatBytes(task.uploaded)} />
        <Metric label="Down speed" value={formatSpeed(task.download_speed)} />
        <Metric label="Up speed" value={formatSpeed(task.upload_speed)} />
        <Metric label="Peers / seeds" value={`${task.peers}/${task.seeds}`} />
      </div>
      {task.error_message && <div className="error-banner">{task.error_message}</div>}
      <div className="drawer-actions">
        <button onClick={() => onAction(task.id, 'resume')} title="Resume">
          <Play size={16} aria-hidden="true" />
          Resume
        </button>
        <button onClick={() => onAction(task.id, 'pause')} title="Pause">
          <Pause size={16} aria-hidden="true" />
          Pause
        </button>
        <button onClick={() => onAction(task.id, 'stop')} title="Stop">
          <Square size={16} aria-hidden="true" />
          Stop
        </button>
      </div>
      <form className="settings-form" onSubmit={submit}>
        <label className="field">
          Category
          <input value={category} onChange={(event) => setCategory(event.target.value)} />
        </label>
        <div className="form-grid">
          <label className="field">
            Priority
            <input
              type="number"
              min="0"
              max="7"
              value={priority}
              onChange={(event) => setPriority(Number(event.target.value))}
            />
          </label>
          <label className="field">
            Down cap
            <input
              type="number"
              min="0"
              value={downloadLimit}
              onChange={(event) => setDownloadLimit(event.target.value)}
            />
          </label>
          <label className="field">
            Up cap
            <input
              type="number"
              min="0"
              value={uploadLimit}
              onChange={(event) => setUploadLimit(event.target.value)}
            />
          </label>
          <label className="field">
            Connections
            <input
              type="number"
              min="0"
              value={maxConnections}
              onChange={(event) => setMaxConnections(event.target.value)}
            />
          </label>
        </div>
        <label className="check-field">
          <input
            type="checkbox"
            checked={sequential}
            onChange={(event) => setSequential(event.target.checked)}
          />
          Sequential download
        </label>
        <button className="primary-button" type="submit">
          <Save size={16} aria-hidden="true" />
          Save
        </button>
      </form>
      <section className="files-section">
        <h3>Files</h3>
        <div className="file-list">
          {files.slice(0, 1000).map((file) => (
            <div className="file-row" key={file.index}>
              <div>
                <strong>{file.path}</strong>
                <span>{formatBytes(file.size)}</span>
              </div>
              <span>{formatPercent(file.progress)}</span>
              {file.download_url && <a href={file.download_url}>Download</a>}
            </div>
          ))}
        </div>
      </section>
      <LogPanel events={events} />
    </aside>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="metric">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
