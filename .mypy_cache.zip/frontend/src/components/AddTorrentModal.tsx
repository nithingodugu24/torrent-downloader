import { FormEvent, useState } from 'react';
import { FileUp, Link, X } from 'lucide-react';

interface AddTorrentModalProps {
  open: boolean;
  onClose: () => void;
  onAddMagnet: (payload: {
    magnet_uri: string;
    save_path?: string;
    category?: string;
    priority: number;
    is_sequential: boolean;
  }) => Promise<void>;
  onAddFile: (payload: {
    file: File;
    save_path?: string;
    category?: string;
    priority: number;
    is_sequential: boolean;
  }) => Promise<void>;
}

export function AddTorrentModal({ open, onClose, onAddMagnet, onAddFile }: AddTorrentModalProps) {
  const [mode, setMode] = useState<'magnet' | 'file'>('magnet');
  const [magnet, setMagnet] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [savePath, setSavePath] = useState('');
  const [category, setCategory] = useState('');
  const [priority, setPriority] = useState(4);
  const [isSequential, setSequential] = useState(false);
  const [busy, setBusy] = useState(false);

  if (!open) return null;

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setBusy(true);
    try {
      if (mode === 'magnet') {
        await onAddMagnet({
          magnet_uri: magnet,
          save_path: savePath || undefined,
          category: category || undefined,
          priority,
          is_sequential: isSequential
        });
      } else if (file) {
        await onAddFile({
          file,
          save_path: savePath || undefined,
          category: category || undefined,
          priority,
          is_sequential: isSequential
        });
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true">
      <form className="modal" onSubmit={submit}>
        <div className="modal-header">
          <h2>Add Torrent</h2>
          <button className="icon-button" type="button" onClick={onClose} title="Close">
            <X size={18} aria-hidden="true" />
          </button>
        </div>
        <div className="segmented">
          <button
            type="button"
            className={mode === 'magnet' ? 'active' : ''}
            onClick={() => setMode('magnet')}
          >
            <Link size={16} aria-hidden="true" />
            Magnet
          </button>
          <button
            type="button"
            className={mode === 'file' ? 'active' : ''}
            onClick={() => setMode('file')}
          >
            <FileUp size={16} aria-hidden="true" />
            File
          </button>
        </div>
        {mode === 'magnet' ? (
          <label className="field">
            Magnet URI
            <textarea
              value={magnet}
              onChange={(event) => setMagnet(event.target.value)}
              required
              rows={5}
              placeholder="magnet:?"
            />
          </label>
        ) : (
          <label className="field">
            .torrent File
            <input
              type="file"
              accept=".torrent"
              required
              onChange={(event) => setFile(event.target.files?.[0] ?? null)}
            />
          </label>
        )}
        <div className="form-grid">
          <label className="field">
            Save path
            <input value={savePath} onChange={(event) => setSavePath(event.target.value)} />
          </label>
          <label className="field">
            Category
            <input value={category} onChange={(event) => setCategory(event.target.value)} />
          </label>
          <label className="field">
            Priority
            <input
              type="number"
              min="0"
              max="7"
              value={priority}
              onChange={(event) => setPriority(Number(event.target.value))}
            />
          </label>
          <label className="check-field">
            <input
              type="checkbox"
              checked={isSequential}
              onChange={(event) => setSequential(event.target.checked)}
            />
            Sequential download
          </label>
        </div>
        <div className="modal-actions">
          <button type="button" className="ghost-button" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="primary-button" disabled={busy}>
            Add
          </button>
        </div>
      </form>
    </div>
  );
}
