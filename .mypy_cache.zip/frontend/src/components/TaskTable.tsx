import { Download, Pause, Play, RotateCcw, Square, Trash2 } from 'lucide-react';
import type { TorrentTask } from '../api/types';
import { formatBytes, formatPercent, formatSpeed } from '../utils/format';

interface TaskTableProps {
  tasks: TorrentTask[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onAction: (id: string, action: string) => void;
}

export function TaskTable({ tasks, selectedId, onSelect, onAction }: TaskTableProps) {
  if (!tasks.length) {
    return (
      <div className="empty-state">
        <Download size={24} aria-hidden="true" />
        <strong>No torrents</strong>
        <span>Legal torrents added here will appear in this dashboard.</span>
      </div>
    );
  }

  return (
    <div className="table-wrap">
      <table className="task-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Status</th>
            <th>Progress</th>
            <th>Down</th>
            <th>Up</th>
            <th>Peers</th>
            <th>Ratio</th>
            <th>Size</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map((task) => (
            <tr
              key={task.id}
              className={task.id === selectedId ? 'selected' : ''}
              onClick={() => onSelect(task.id)}
            >
              <td>
                <div className="task-name">{task.name || 'Metadata pending'}</div>
                <div className="task-subline">{task.category || task.info_hash || task.id}</div>
              </td>
              <td>
                <span className={`status-chip ${task.status}`}>{task.status}</span>
              </td>
              <td>
                <div className="progress-cell">
                  <div className="progress-track">
                    <div className="progress-fill" style={{ width: `${task.progress * 100}%` }} />
                  </div>
                  <span>{formatPercent(task.progress)}</span>
                </div>
              </td>
              <td>{formatSpeed(task.download_speed)}</td>
              <td>{formatSpeed(task.upload_speed)}</td>
              <td>
                {task.peers}/{task.seeds}
              </td>
              <td>{task.ratio.toFixed(2)}</td>
              <td>{formatBytes(task.total_size)}</td>
              <td>
                <div className="row-actions" onClick={(event) => event.stopPropagation()}>
                  <button title="Resume" onClick={() => onAction(task.id, 'resume')}>
                    <Play size={15} aria-hidden="true" />
                  </button>
                  <button title="Pause" onClick={() => onAction(task.id, 'pause')}>
                    <Pause size={15} aria-hidden="true" />
                  </button>
                  <button title="Stop" onClick={() => onAction(task.id, 'stop')}>
                    <Square size={15} aria-hidden="true" />
                  </button>
                  <button title="Recheck" onClick={() => onAction(task.id, 'recheck')}>
                    <RotateCcw size={15} aria-hidden="true" />
                  </button>
                  <button title="Remove" onClick={() => onAction(task.id, 'remove')}>
                    <Trash2 size={15} aria-hidden="true" />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
