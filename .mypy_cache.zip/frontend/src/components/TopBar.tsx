import { Plus, RefreshCcw, ShieldCheck } from 'lucide-react';

interface TopBarProps {
  connected: boolean;
  onAdd: () => void;
  onRefresh: () => void;
}

export function TopBar({ connected, onAdd, onRefresh }: TopBarProps) {
  return (
    <header className="topbar">
      <div className="brand-block">
        <div className="brand-mark">U</div>
        <div>
          <h1>UWSLeech</h1>
          <div className="legal-copy">
            <ShieldCheck size={15} aria-hidden="true" />
            Legal, user-authorized torrents only
          </div>
        </div>
      </div>
      <div className="topbar-actions">
        <span className={`connection-pill ${connected ? 'online' : 'offline'}`}>
          {connected ? 'Live' : 'Offline'}
        </span>
        <button className="icon-button" type="button" onClick={onRefresh} title="Refresh">
          <RefreshCcw size={18} aria-hidden="true" />
        </button>
        <button className="primary-button" type="button" onClick={onAdd}>
          <Plus size={18} aria-hidden="true" />
          Add
        </button>
      </div>
    </header>
  );
}
