import { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import type { TaskEvent } from '../api/types';

export function LogPanel({ events }: { events: TaskEvent[] }) {
  const [query, setQuery] = useState('');
  const filtered = useMemo(() => {
    const needle = query.toLowerCase();
    return events.filter(
      (event) =>
        event.message.toLowerCase().includes(needle) ||
        event.level.toLowerCase().includes(needle) ||
        event.event_type.toLowerCase().includes(needle)
    );
  }, [events, query]);

  return (
    <section className="log-panel">
      <div className="section-header">
        <h3>Logs</h3>
        <label className="mini-search">
          <Search size={14} aria-hidden="true" />
          <input value={query} onChange={(event) => setQuery(event.target.value)} />
        </label>
      </div>
      <div className="log-list">
        {filtered.map((event) => (
          <div className={`log-row ${event.level}`} key={event.id}>
            <time>{new Date(event.created_at).toLocaleTimeString()}</time>
            <strong>{event.event_type}</strong>
            <span>{event.message}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
