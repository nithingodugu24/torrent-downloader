import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  addMagnet,
  listEvents,
  listFiles,
  listTorrents,
  torrentAction,
  updateTorrent,
  uploadTorrent,
  websocketUrl
} from '../api/client';
import type { TaskEvent, TorrentFile, TorrentPatch, TorrentTask, TorrentUpdateMessage } from '../api/types';

export function useTorrents() {
  const [tasks, setTasks] = useState<TorrentTask[]>([]);
  const [events, setEvents] = useState<TaskEvent[]>([]);
  const [files, setFiles] = useState<TorrentFile[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState('');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('created_at');
  const [order, setOrder] = useState<'asc' | 'desc'>('desc');
  const [error, setError] = useState<string | null>(null);
  const [connected, setConnected] = useState(false);

  const refresh = useCallback(async () => {
    const params = new URLSearchParams();
    if (statusFilter) params.set('status', statusFilter);
    if (search) params.set('search', search);
    params.set('sort', sort);
    params.set('order', order);
    setTasks(await listTorrents(params));
  }, [order, search, sort, statusFilter]);

  useEffect(() => {
    refresh().catch((err: Error) => setError(err.message));
  }, [refresh]);

  useEffect(() => {
    const socket = new WebSocket(websocketUrl());
    socket.onopen = () => setConnected(true);
    socket.onclose = () => setConnected(false);
    socket.onerror = () => setConnected(false);
    socket.onmessage = (event) => {
      const message = JSON.parse(event.data) as TorrentUpdateMessage;
      if (message.event === 'removed') {
        setTasks((current) => current.filter((task) => task.id !== message.task.id));
        setSelectedId((current) => (current === message.task.id ? null : current));
        return;
      }
      setTasks((current) =>
        current.map((task) => (task.id === message.task.id ? { ...task, ...message.task } : task))
      );
    };
    return () => socket.close();
  }, []);

  useEffect(() => {
    if (!selectedId) {
      setEvents([]);
      setFiles([]);
      return;
    }
    Promise.all([listEvents(selectedId), listFiles(selectedId)])
      .then(([nextEvents, nextFiles]) => {
        setEvents(nextEvents);
        setFiles(nextFiles);
      })
      .catch((err: Error) => setError(err.message));
  }, [selectedId, tasks]);

  const selectedTask = useMemo(
    () => tasks.find((task) => task.id === selectedId) ?? null,
    [selectedId, tasks]
  );

  const runAction = async (id: string, action: string) => {
    setError(null);
    const next = await torrentAction(id, action);
    if (action === 'remove') {
      setTasks((current) => current.filter((task) => task.id !== id));
      setSelectedId((current) => (current === id ? null : current));
      return;
    }
    setTasks((current) => current.map((task) => (task.id === id ? next : task)));
  };

  const patchTask = async (id: string, patch: TorrentPatch) => {
    setError(null);
    const next = await updateTorrent(id, patch);
    setTasks((current) => current.map((task) => (task.id === id ? next : task)));
  };

  const addMagnetTask = async (payload: Parameters<typeof addMagnet>[0]) => {
    setError(null);
    const next = await addMagnet(payload);
    setTasks((current) => [next, ...current]);
    setSelectedId(next.id);
  };

  const addFileTask = async (payload: Parameters<typeof uploadTorrent>[0]) => {
    setError(null);
    const next = await uploadTorrent(payload);
    setTasks((current) => [next, ...current]);
    setSelectedId(next.id);
  };

  return {
    tasks,
    events,
    files,
    selectedTask,
    selectedId,
    setSelectedId,
    statusFilter,
    setStatusFilter,
    search,
    setSearch,
    sort,
    setSort,
    order,
    setOrder,
    error,
    setError,
    connected,
    refresh,
    runAction,
    patchTask,
    addMagnetTask,
    addFileTask
  };
}
