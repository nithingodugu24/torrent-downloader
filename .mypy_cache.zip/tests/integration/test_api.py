from __future__ import annotations

from pathlib import Path

import httpx
import pytest
from app.api import events, torrents
from app.config import Settings
from app.db.models import Base
from app.db.session import get_db
from app.services.broadcaster import TorrentBroadcaster
from app.services.torrent_service import TorrentService
from fastapi import FastAPI
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from tests.integration.test_service import FakeEngine

pytestmark = pytest.mark.anyio


@pytest.fixture()
def anyio_backend() -> str:
    return "asyncio"


@pytest.fixture()
async def test_app(tmp_path: Path):
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    session_factory = async_sessionmaker(engine, expire_on_commit=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async def override_db():
        async with session_factory() as session:
            yield session

    settings = Settings(
        database_url="sqlite+aiosqlite:///:memory:",
        storage_root=tmp_path / "downloads",
        torrent_state_dir=tmp_path / "state",
        torrent_file_dir=tmp_path / "torrent-files",
    )
    settings.ensure_directories()
    app = FastAPI()
    app.state.broadcaster = TorrentBroadcaster()
    app.state.torrent_service = TorrentService(settings, FakeEngine(), app.state.broadcaster)
    app.dependency_overrides[get_db] = override_db
    app.include_router(torrents.router)
    app.include_router(events.router)
    yield app
    await engine.dispose()


async def test_create_and_list_magnet_via_api(test_app: FastAPI) -> None:
    transport = httpx.ASGITransport(app=test_app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        create_response = await client.post(
            "/api/torrents/magnet",
            json={
                "magnet_uri": "magnet:?xt=urn:btih:0123456789012345678901234567890123456789",
                "category": "public-domain",
            },
        )
        assert create_response.status_code == 201

        list_response = await client.get("/api/torrents")
        assert list_response.status_code == 200
        payload = list_response.json()
        assert len(payload) == 1
        assert payload[0]["category"] == "public-domain"


async def test_remove_magnet_deletes_from_api_list(test_app: FastAPI) -> None:
    transport = httpx.ASGITransport(app=test_app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        create_response = await client.post(
            "/api/torrents/magnet",
            json={
                "magnet_uri": "magnet:?xt=urn:btih:0123456789012345678901234567890123456789",
            },
        )
        task_id = create_response.json()["id"]

        remove_response = await client.post(f"/api/torrents/{task_id}/remove")
        list_response = await client.get("/api/torrents")

        assert remove_response.status_code == 204
        assert list_response.json() == []
