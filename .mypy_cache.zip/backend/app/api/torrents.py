from __future__ import annotations

from dataclasses import asdict
from pathlib import Path

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Response,
    UploadFile,
    status,
)
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_torrent_service
from app.db.session import get_db
from app.schemas.torrent import MagnetCreate, TorrentFileRead, TorrentPatch, TorrentTaskRead
from app.services.torrent_service import TorrentService
from app.utils.paths import safe_resolve_under_root

router = APIRouter(prefix="/api/torrents", tags=["torrents"])


@router.post("/magnet", response_model=TorrentTaskRead, status_code=201)
async def add_magnet(
    payload: MagnetCreate,
    db: AsyncSession = Depends(get_db),
    service: TorrentService = Depends(get_torrent_service),
) -> TorrentTaskRead:
    task = await service.add_magnet(
        db,
        payload.magnet_uri,
        payload.save_path,
        payload.category,
        payload.priority,
        payload.is_sequential,
    )
    return TorrentTaskRead.model_validate(task)


@router.post("/file", response_model=TorrentTaskRead, status_code=201)
async def add_torrent_file(
    file: UploadFile = File(...),
    save_path: str | None = Form(default=None),
    category: str | None = Form(default=None),
    priority: int = Form(default=4),
    is_sequential: bool = Form(default=False),
    db: AsyncSession = Depends(get_db),
    service: TorrentService = Depends(get_torrent_service),
) -> TorrentTaskRead:
    content = await file.read(service.settings.max_upload_size_mb * 1024 * 1024 + 1)
    task = await service.add_torrent_file(
        db,
        file.filename or "upload.torrent",
        content,
        save_path,
        category,
        priority,
        is_sequential,
    )
    return TorrentTaskRead.model_validate(task)


@router.get("", response_model=list[TorrentTaskRead])
async def list_torrents(
    status: str | None = Query(default=None),
    search: str | None = Query(default=None),
    sort: str = Query(default="created_at"),
    order: str = Query(default="desc", pattern="^(asc|desc)$"),
    db: AsyncSession = Depends(get_db),
    service: TorrentService = Depends(get_torrent_service),
) -> list[TorrentTaskRead]:
    tasks = await service.list_tasks(db, status, search, sort, order)
    return [TorrentTaskRead.model_validate(task) for task in tasks]


@router.get("/{task_id}", response_model=TorrentTaskRead)
async def get_torrent(
    task_id: str,
    db: AsyncSession = Depends(get_db),
    service: TorrentService = Depends(get_torrent_service),
) -> TorrentTaskRead:
    task = await service.get_task(db, task_id)
    return TorrentTaskRead.model_validate(task)


@router.patch("/{task_id}", response_model=TorrentTaskRead)
async def update_torrent(
    task_id: str,
    payload: TorrentPatch,
    db: AsyncSession = Depends(get_db),
    service: TorrentService = Depends(get_torrent_service),
) -> TorrentTaskRead:
    task = await service.update_task(db, task_id, payload)
    return TorrentTaskRead.model_validate(task)


@router.post("/{task_id}/start", response_model=TorrentTaskRead)
async def start_torrent(
    task_id: str,
    db: AsyncSession = Depends(get_db),
    service: TorrentService = Depends(get_torrent_service),
) -> TorrentTaskRead:
    task = await service.action(db, task_id, "start")
    return TorrentTaskRead.model_validate(task)


@router.post("/{task_id}/pause", response_model=TorrentTaskRead)
async def pause_torrent(
    task_id: str,
    db: AsyncSession = Depends(get_db),
    service: TorrentService = Depends(get_torrent_service),
) -> TorrentTaskRead:
    task = await service.action(db, task_id, "pause")
    return TorrentTaskRead.model_validate(task)


@router.post("/{task_id}/resume", response_model=TorrentTaskRead)
async def resume_torrent(
    task_id: str,
    db: AsyncSession = Depends(get_db),
    service: TorrentService = Depends(get_torrent_service),
) -> TorrentTaskRead:
    task = await service.action(db, task_id, "resume")
    return TorrentTaskRead.model_validate(task)


@router.post("/{task_id}/stop", response_model=TorrentTaskRead)
async def stop_torrent(
    task_id: str,
    db: AsyncSession = Depends(get_db),
    service: TorrentService = Depends(get_torrent_service),
) -> TorrentTaskRead:
    task = await service.action(db, task_id, "stop")
    return TorrentTaskRead.model_validate(task)


@router.post("/{task_id}/remove", status_code=status.HTTP_204_NO_CONTENT)
async def remove_torrent(
    task_id: str,
    delete_files: bool = Query(default=False),
    db: AsyncSession = Depends(get_db),
    service: TorrentService = Depends(get_torrent_service),
) -> Response:
    await service.action(db, task_id, "remove", delete_files=delete_files)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/{task_id}/recheck", response_model=TorrentTaskRead)
async def recheck_torrent(
    task_id: str,
    db: AsyncSession = Depends(get_db),
    service: TorrentService = Depends(get_torrent_service),
) -> TorrentTaskRead:
    task = await service.action(db, task_id, "recheck")
    return TorrentTaskRead.model_validate(task)


@router.get("/{task_id}/files", response_model=list[TorrentFileRead])
async def list_files(
    task_id: str,
    db: AsyncSession = Depends(get_db),
    service: TorrentService = Depends(get_torrent_service),
) -> list[TorrentFileRead]:
    task = await service.get_task(db, task_id)
    files = await service.get_files(db, task_id)
    result: list[TorrentFileRead] = []
    for item in files:
        file_path = safe_resolve_under_root(Path(task.save_path), item.path)
        download_url = (
            f"/api/torrents/{task_id}/files/{item.index}/download"
            if task.status in {"completed", "seeding"} and file_path.is_file()
            else None
        )
        result.append(TorrentFileRead(**asdict(item), download_url=download_url))
    return result


@router.get("/{task_id}/files/{file_index}/download")
async def download_file(
    task_id: str,
    file_index: int,
    db: AsyncSession = Depends(get_db),
    service: TorrentService = Depends(get_torrent_service),
) -> FileResponse:
    task = await service.get_task(db, task_id)
    if task.status not in {"completed", "seeding"}:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Files are available for browser download after the torrent completes.",
        )
    files = await service.get_files(db, task_id)
    match = next((item for item in files if item.index == file_index), None)
    if not match:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found.")
    file_path = safe_resolve_under_root(Path(task.save_path), match.path)
    return FileResponse(file_path, filename=Path(match.path).name)
